export default class ScansController {
    constructor($scope, $rootScope) {
      "ngInject"
        this.name = 'scans';
        this.itemsCount = 0;
        this.check1 = true;
        this.scanListTitle = "Last Completed Scans";

        this.tooltipMessages = [{
            "name": "lastCompletedScans",
            "message": "Information presented here relates to the last completed scan...to test data"
        },{
            "name": "name1",
            "message": "Information presented here relates to the last completed scan...to test data"
        },{
            "name": "name2",
            "message": "Information presented here relates to the last completed scan...to test data"
        },{
            "name": "name3",
            "message": "Information presented here relates to the last completed scan...to test data"
        },{
            "name": "name4",
            "message": "Information presented here relates to the last completed scan...to test data"}];


        if (this.mode == undefined || this.mode == null || this.mode == '') {
          this.mode = 'last';
        }

        $scope.$on("mode:changed", (event, mode) =>  {
          // console.log('ScansController: mode:changed', event, mode);
          this.mode = mode;

          if (mode == 'last') {
            this.scanListTitle = "Last Completed Scans";
          }
          else{
            this.scanListTitle = "All Completed Scans";
            this.pid = 0;
          }
        });

    }

    // getDataTooltip(name){
    //
    //   //$ctrl.getDataTooltip
    //
    //   var data=this.tooltipMessages;
    //   var result;
    //
    // if(name=="lastCompletedScans"){
    //   if(this.scanListTitle=="Last Completed Scans"){
    //     result=data[0].message;
    //   }else {
    //     result=data[1].message;
    //   }
    // }
    //
    // if(name2==""){
    //     result=data[2].message;
    // }
    //
    // if(name3==""){
    //     result=data[3].message;
    // }
    // if(name4==""){
    //     result=data[4].message;
    // }
    //
    // if(name5==""){
    //     result=data[5].message;
    // }
    //
    // if(name6==""){
    //     result=data[6].message;
    // }

}
