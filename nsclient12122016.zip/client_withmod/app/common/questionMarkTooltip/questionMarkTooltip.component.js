import template from './questionMarkTooltip.html';
import controller from './questionMarkTooltip.controller';
import './questionMarkTooltip.styl';

let questionMarkTooltipComponent = ($popover) => {
    return {
        restrict: 'A',
        template,
        controller,
        link: (scope, elem, attr) => {

          "use strict";

          let myPopover = $popover(elem, {
            scope: scope,
            placement: 'top',
            container: 'body',
            trigger: 'click',
            autoClose: true,
            templateUrl: 'app/common/questionMarkTooltip/questionMarkTooltip.html'
          });

        }
    };
};

export default questionMarkTooltipComponent;
