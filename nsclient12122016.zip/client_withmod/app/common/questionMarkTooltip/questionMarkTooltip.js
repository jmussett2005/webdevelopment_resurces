import angular from 'angular';
import uiRouter from 'angular-ui-router';
import questionMarkTooltipComponent from './questionMarkTooltip.component';

let questionMarkTooltipModule = angular.module('questionMarkTooltip', [
  uiRouter
])

.directive('questionMarkTooltip', questionMarkTooltipComponent)

.name;

export default questionMarkTooltipModule;
