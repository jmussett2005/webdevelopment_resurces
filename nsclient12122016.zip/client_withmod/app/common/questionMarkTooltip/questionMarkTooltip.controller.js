export default class QuestionMarkTooltipController {
    constructor() {
        this.name = 'questionMarkTooltip';
    }
}
