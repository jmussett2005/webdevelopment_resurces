import controller from './vulPopup.controller';
import './vulPopup.styl';
import template from './vulPopup.html';

var prev = null;

let vulPopupComponent = ($popover) => {
  "ngInject";
  return {
    restrict: 'A',
    bindings: {
      api: '&',
      type: '@',
      sid: '@',
      high: '@',
      newhigh: '@',
      medium: '@',
      newmedium: '@',
      low: '@',
      newlow: '@'
    },
    scope: {
      vulPopup: '&',
      trigger: '@'
    },
    template,
    controller,
    link: (scope, elem, attr) => {
      "use strict";

      let myPopover = $popover(elem, {
        scope: scope,
        placement: 'top',
        container: 'body',
        trigger: 'manual',
        autoClose: true,
        templateUrl: 'app/common/vulPopup/vulPopup.html'
      });

	  let delaiedHide = ()=>{
     setTimeout(function() { closePopup() }, 500);
	  }

	  function closePopup(){
		  myPopover.hide();
	  }

      let showPopup = ()=>{
        scope.vulPopup()
          .then(d => {

            let promise = d.vulnerabilities;
            promise.then(
              function(payload) {
				if (prev != null)
					prev.hide();

				prev=myPopover;


        let vulnerabilities = payload.data;
        d = {
          scanId: d.scanId,
          severity: d.severity,
          status_new: d.status_new,
          vulnerabilities: vulnerabilities
        };

        myPopover.$promise.then(myPopover.show);

        scope.data = d.vulnerabilities;
        scope.scanId=d.scanId;
        scope.severity=d.severity;
        scope.status_new=d.status_new;
        scope.total_vul=0;
        // console.log('vulPopupComponent: severity', d.severity);
        // console.log('vulPopupComponent: status_new', d.status_new);
        // console.log('vulPopupComponent: vulnerabilities', d.vulnerabilities);
        let total = 0;
        d.vulnerabilities.vulnerabilities.forEach(function(item) {
          total += item.count;
        });
        // console.log('vulPopupComponent: Total', total);
        scope.total_vul= total;
        // // let vulnerabilities = payload.data;
        // d = {
        //   scanId: d.scanId,
        //   severity: d.severity,
        //   vulnerabilities: vulnerabilities
        // };
        // // console.log('vulPopupComponent: d', d);
        // myPopover.$promise.then(myPopover.show);
        // scope.data = d.vulnerabilities;
        // console.log('vulPopupComponent: scope.data', scope.data);
      },
      function(errorPayload) {
        $log.error('failure loading data', errorPayload);
      });
          });
      }

      if(scope.trigger === 'manual'){
        showPopup;
      } else {
        elem.on('mouseenter', showPopup);

        elem.on('mouseout', () => {
          myPopover.$promise.then(delaiedHide);
        });
      }


    }
  };
};

export default vulPopupComponent;
