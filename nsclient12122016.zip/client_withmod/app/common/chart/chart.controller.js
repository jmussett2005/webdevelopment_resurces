export default class ChartController {
    constructor($stateParams, $scope, $compile, $q, $timeout, projectsService, $rootScope) {
        "ngInject";
        this.projectsService = projectsService;
        this.$q = $q;
        this.$compile = $compile;
        this.$timeout = $timeout;
        this.$scope = $scope;
        this.name = 'Vulnerabilities Status';
        this.mode = $stateParams.mode;
        // console.log('ChartController: $stateParams', $stateParams);
        // console.log('ChartController: this.sid', this.sid, 'sid', sid);
        if (this.mode == '' || this.mode == null || this.mode == undefined) {
            this.mode == 'last'
        }
        this.summary$ = this.getSummary($stateParams.sid, this.mode);

        $scope.$on("scanId:changed", (event, sid, datetime) =>  {
          this.getSummary(sid, this.mode);
        });
        // console.log('ChartController: this.sid', this.sid, 'sid', sid);
        $scope.$on("mode:changed", (event, mode) =>  {
          // console.log('ChartController: mode:changed', mode, this.sid);
          this.mode = mode;
          if (mode == 'all')
          {
            this.pid = 0;
          }
          this.getSummary(this.sid, this.pid, this.mode);
        });

        $scope.$on("maxValue:changed", (event, maxValue) =>  {
           console.log('ChartController: maxValue:changed', event, maxValue);
        })
        // console.log('ChartController: this.sid', this.sid, 'sid', sid);
        let popupScope = $scope.$new();

        popupScope.getPopupData = (type, sev, pid, sid, snew) => {
          // console.log('popupScope.getPopupData', type, sev, sid, snew);
            let vulnerabilities = this.projectsService.getVolnerabilityBreakdown$(type, sev, pid, sid, snew);
            var data =  {
                scanId: sid,
                severity: sev,
                pid: pid,
                new: snew,
                vulnerabilities: vulnerabilities
            };
            return this.$q.resolve(data);
        };

        this.popup = (type, sev, pid, sid, snew) => {
            let popup = `<div style="background: black; width: 100px;" data-vul-popup="getPopupData('${type}', ${sev}, ${pid}, ${sid}, ${snew})" trigger="manual"></div>`;
            let compiledPopup =  $compile(popup)(popupScope);
            return ( graphDataItem, amGraph ) => {
            };
        };
    }

    getSummary(sid, pid, mode) {
        this.projectsService.mode = mode;
        this.projectsService.sid = sid;
        this.projectsService.pid = pid;
        // console.log('projects service chart', this.projectsService);
        return this.projectsService.chartSummaryData$.subscribe(
            x => {
                this.summary = x.data;
                this.chartData = [{
                    "RiskLevel": "High",
                    "High": this.summary.high - this.summary.newHigh,
                    "HighNew": this.summary.newHigh
                }, {
                    "RiskLevel": "Medium",
                    "Medium": this.summary.medium - this.summary.newMedium,
                    "MediumNew": this.summary.newMedium
                }, {
                    "RiskLevel": "Low",
                    "Low": this.summary.low - this.summary.newLow,
                    "LowNew": this.summary.newLow
                }];

                // SERIAL CHART
                let chart;
                chart = new AmCharts.AmSerialChart();
                chart.dataProvider = this.chartData;
                chart.categoryField = "RiskLevel";
                chart.plotAreaBorderAlpha = 0;
                chart.columnWidth = 0.2;
                chart.autoMargins = true;
                chart.marginTop = 23;
                chart.fontSize = 0;
                chart.responsive = true;

                // AXES
                // category
                var categoryAxis = chart.categoryAxis;
                categoryAxis.gridAlpha = 0;
                categoryAxis.axisAlpha = 1;
                categoryAxis.axisThickness = 2;
                categoryAxis.equalSpacing = true;
                categoryAxis.gridPosition = 'start';
                categoryAxis.labelsEnabled = true;
                categoryAxis.fontSize = 13;
                categoryAxis.color = '#9b9b9b';

                // value
                var valueAxis = new AmCharts.ValueAxis();
                valueAxis.stackType = "regular";
                valueAxis.gridAlpha = 0.1;
                valueAxis.axisAlpha = 0;
                valueAxis.position = 'right';
                valueAxis.color = '#9b9b9b';
                valueAxis.autoGridCount = false;
                valueAxis.gridCount = 4;
                valueAxis.labelsEnabled = true;
                valueAxis.showFirstLabel = false;
                valueAxis.fontSize = 13;
                valueAxis.integersOnly = true;

                chart.addValueAxis(valueAxis);

                // GRAPHS
                // first graph
                var graph = new AmCharts.AmGraph();
                graph.title = "High";
                graph.labelText = "[[value]]";
                graph.valueField = "High";
                graph.type = "column";
                graph.lineAlpha = 0;
                graph.fillAlphas = 1;
                graph.lineColor = "#da2945";
                graph.balloonFunction = this.popup('completed', 3, pid, 0, false);
                //  graph.balloon.offsetX = 100;
                graph.showAllValueLabels= true;
                graph.pointPosition = 'middle';
                chart.addGraph(graph);

                // second graph
                graph = new AmCharts.AmGraph();
                graph.title = "New";
                graph.labelText = "[[value]]";
                graph.valueField = "HighNew";
                graph.type = "column";
                graph.lineAlpha = 0;
                graph.fillAlphas = 1;
                graph.lineColor = "#D8E0BD";
                graph.balloonFunction = this.popup('completed', 3, pid, 0, true);
                graph.pattern = {
                    "url": "../assets/img/chart/high-new.png",
                    "width": 80,
                    "height": 92
                };
                chart.addGraph(graph);

                // third graph
                graph = new AmCharts.AmGraph();
                graph.title = "Medium";
                graph.labelText = "[[value]]";
                graph.valueField = "Medium";
                graph.type = "column";
                graph.lineAlpha = 0;
                graph.fillAlphas = 1;
                graph.lineColor = "#ffb400";
                // graph.balloonText = "<span style='color:#555555;'>sss[[category]]</span><br><span style='font-size:14px'>qqq[[title]]:<b>[[value]]</b></span>";
                graph.balloonFunction = this.popup('completed', 2, pid, 0, false);
                chart.addGraph(graph);

                // fourth graph
                graph = new AmCharts.AmGraph();
                graph.title = "New";
                graph.labelText = "[[value]]";
                graph.valueField = "MediumNew";
                graph.type = "column";
                graph.lineAlpha = 0;
                graph.fillAlphas = 1;
                graph.lineColor = "#ffb999";
                // graph.balloonText = "<span style='color:#555555;'>[[category]]</span><br><span style='font-size:14px'>[[title]]:<b>[[value]]</b></span>";
                graph.balloonFunction = this.popup('completed', 2, pid, 0, true);
                graph.pattern = {
                    "url": "../assets/img/chart/medium-new.png",
                    "width": 103,
                    "height": 104
                };
                chart.addGraph(graph);

                // fifth graph
                graph = new AmCharts.AmGraph();
                graph.title = "Low";
                graph.labelText = "[[value]]";
                graph.valueField = "Low";
                graph.type = "column";
                graph.lineAlpha = 0;
                graph.fillAlphas = 1;
                graph.lineColor = "#FFE10A";
                // graph.balloonText = "<span style='color:#555555;'>[[category]]</span><br><span style='font-size:14px'>[[title]]:<b>[[value]]</b></span>";
                graph.balloonFunction = this.popup('completed', 1, pid, 0, false);
                chart.addGraph(graph);

                // sixth graph
                graph = new AmCharts.AmGraph();
                graph.title = "New";
                graph.labelText = "[[value]]";
                graph.valueField = "LowNew";
                graph.type = "column";
                graph.lineAlpha = 0;
                graph.fillAlphas = 1;
                graph.lineColor = "#F4E23B";
                // graph.balloonText = "<span style='color:#555555;'>[[category]]</span><br><span style='font-size:14px'>[[title]]:<b>[[value]]</b></span>";
                graph.balloonFunction = this.popup('completed', 1, pid, 0, true);
                graph.pattern = {
                    "url": "../assets/img/chart/low-new.png",
                    "width": 116,
                    "height": 112
                };
                chart.addGraph(graph);

                // WRITE
                chart.write("chartdiv");
            });
    }
}
