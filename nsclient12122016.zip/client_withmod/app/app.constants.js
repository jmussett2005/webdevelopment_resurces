// === The server url for getting data ===
export const SERVER_URL = 'http://10.31.2.156:8080/iast-manager/api';
//export const SERVER_URL = 'http://52.214.173.31:8080/REST_API/iast-manager/api';
//export const SERVER_URL = 'http://10.31.2.79:8080/iast-manager/api';
//export const SERVER_URL = 'http://10.31.1.32:8080/iast-manager/api';
// export const SERVER_URL = 'http://localhost:3008';
export const PULL_DELAY_PROJECTS = 10000;
export const PULL_DELAY_INF = 99999999999999;
export const PROJECTS_LINK = 'http://52.213.113.192:443/';
export const VUL_OVR_TIME_PAGE_SIZE = 6;
export const VUL_OVR_TIME_VERTICAL_OFFSET = 0;
