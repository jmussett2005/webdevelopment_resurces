import angular      from 'angular';
import Dashboard from './dashboard/dashboard';
import Projects from './projects/projects';
import projectlobby from './projectlobby/projectlobby';
import scanResultsItem from './scanResultsItem/scanResultsItem';
import uniqueRequestsGraph from './uniqueRequestsGraph/uniqueRequestsGraph';
import scanResultsList from './scanResultsList/scanResultsList';
import scanResultsDetails from './scanResultsDetails/scanResultsDetails';
import allActivities from './allActivities/allActivities';

let componentModule = angular.module('app.components', [
    Dashboard,
    Projects,
    projectlobby,
    uniqueRequestsGraph,
    scanResultsItem,
    scanResultsList,
    scanResultsDetails,
    allActivities
])
.name;

export default componentModule;
