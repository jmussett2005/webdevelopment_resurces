import angular from 'angular';
import uiRouter from 'angular-ui-router';
import scansComponent from './scans.component';
import ScansItems from '../scansItems/scansItems';

let scansModule = angular.module('scans', [
    uiRouter,
    ScansItems
])

.component('scans', scansComponent)

.name;

export default scansModule;
