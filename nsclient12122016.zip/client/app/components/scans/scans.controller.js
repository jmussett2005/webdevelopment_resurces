export default class ScansController {
    constructor($scope, $rootScope, $q, $timeout) {
      "ngInject"
        this.name = 'scans';
        this.itemsCount = 0;
        this.check1 = true;
        this.scanListTitle = "Last Completed Scans";
        this.$q = $q;
        this.$timeout = $timeout;

        this.tooltipMessages = [{
            "name": "lastCompletedScans",
            "message": "Information presented here relates to the last completed scan...to test data"
        },{
            "name": "name1",
            "message": "Information presented here relates to the all complete scans...to test data"
        },{
            "name": "name2",
            "message": "Information presented here relates to the last completed scan...to test data"
        },{
            "name": "name3",
            "message": "Information presented here relates to the last completed scan...to test data"
        },{
            "name": "name4",
            "message": "Information presented here relates to the last completed scan...to test data"
        },{
            "name": "name5",
            "message": "Information presented here relates to the last completed scan...to test data"}];

        if (this.mode == undefined || this.mode == null || this.mode == '') {
          this.mode = 'last';
        }

        $scope.$on("mode:changed", (event, mode) =>  {
          // console.log('ScansController: mode:changed', event, mode);
          this.mode = mode;

          if (mode == 'last') {
            this.scanListTitle = "Last Completed Scans";
          }
          else{
            this.scanListTitle = "All Completed Scans";
            this.pid = 0;
          }
        });

    }

    // testFun(){
    //   console.log("---------------------");
    // }

    getDataTooltip(name){

       var datatmp=this.tooltipMessages;
       var resultDT;
       var data;

    if(name==="lastCompletedScans"){
       if(this.scanListTitle=="Last Completed Scans"){
         resultDT=datatmp[0].message;
       }else {
         resultDT=datatmp[1].message;
       }
     }
     if(name==="name2"){
         resultDT=datatmp[2].message;
     }
     if(name==="name3"){
         resultDT=datatmp[3].message;
     }
     if(name==="name4"){
         resultDT=datatmp[4].message;
     }
     if(name==="name5"){
         resultDT=datatmp[5].message;
     }
     if(name==="name6"){
         resultDT=datatmp[6].message;
     }

     data={
       desc:resultDT
     }

     return this.$q(resolve => {

       this.$timeout(() => {
         resolve(data);
         console.log(data);
       });
     });
}
}
