import template from './scans.html';
import controller from './scans.controller';
import './scans.styl';

let scansComponent = {
  restrict: 'E',
  bindings: {},
  template,
  controller
};

export default scansComponent;
