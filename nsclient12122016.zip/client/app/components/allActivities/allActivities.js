import angular from 'angular';
import uiRouter from 'angular-ui-router';
import allActivitiesComponent from './allActivities.component';

let allActivitiesModule = angular.module('allActivities', [
  uiRouter
])

.config(($stateProvider) => {
    "ngInject";
    $stateProvider
        .state('all-activities', {
            url: '/all-activities',
            component: 'allActivities'
        });
})

.component('allActivities', allActivitiesComponent)

.name;

export default allActivitiesModule;
