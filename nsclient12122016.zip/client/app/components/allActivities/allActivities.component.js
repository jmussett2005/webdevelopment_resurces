import template from './allActivities.html';
import controller from './allActivities.controller';
import './allActivities.styl';

let allActivitiesComponent = {
  restrict: 'E',
  bindings: {},
  template,
  controller
};

export default allActivitiesComponent;
