import AllActivitiesModule from './allActivities'
import AllActivitiesController from './allActivities.controller';
import AllActivitiesComponent from './allActivities.component';
import AllActivitiesTemplate from './allActivities.html';

describe('AllActivities', () => {
  let $rootScope, makeController;

  beforeEach(window.module(AllActivitiesModule));
  beforeEach(inject((_$rootScope_) => {
    $rootScope = _$rootScope_;
    makeController = () => {
      return new AllActivitiesController();
    };
  }));

  describe('Module', () => {
    // top-level specs: i.e., routes, injection, naming
  });

  describe('Controller', () => {
    // controller specs
    it('has a name property [REMOVE]', () => { // erase if removing this.name from the controller
      let controller = makeController();
      expect(controller).to.have.property('name');
    });
  });

  describe('Template', () => {
    // template specs
    // tip: use regex to ensure correct bindings are used e.g., {{  }}
    it('has name in template [REMOVE]', () => {
      expect(AllActivitiesTemplate).to.match(/{{\s?\$ctrl\.name\s?}}/g);
    });
  });

  describe('Component', () => {
      // component/directive specs
      let component = AllActivitiesComponent;

      it('includes the intended template',() => {
        expect(component.template).to.equal(AllActivitiesTemplate);
      });

      it('invokes the right controller', () => {
        expect(component.controller).to.equal(AllActivitiesController);
      });
  });
});
