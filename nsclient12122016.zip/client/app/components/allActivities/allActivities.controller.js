export default class AllActivitiesController {
    constructor(projectsService) {
        "ngInject";
        this.name = 'Top 100 activities';
        this.projectsService = projectsService;
        this.currentPage = 1;
        this.viewby = 10;
        this.options = [5, 10, 15, 20, 25, 50];
    }
    $onInit() {
        this.getActivity();
        this.itemsPerPage = this.viewby;
    }
    getActivity() {
        return this.projectsService.activityData$.subscribe(x => {
            this.allActivityItems = x.data.activities;
            this.totalItems = x.data.activities.length;
        });
    }
    setItemsPerPage(num) {
        this.itemsPerPage = num;
        this.currentPage = 1;
    }
}
