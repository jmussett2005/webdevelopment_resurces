import template from './scanResultsDetails.html';
import controller from './scanResultsDetails.controller';
import './scanResultsDetails.styl';

let scanResultsDetailsComponent = {
    restrict: 'E',
    bindings: { rid: '<' },
    template,
    controller
};

export default scanResultsDetailsComponent;
