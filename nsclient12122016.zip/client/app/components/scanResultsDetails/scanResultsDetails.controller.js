export default class ScanResultsDetailsController {
    constructor($stateParams, projectsService, $sce) {
        'ngInject';
        this.projectsService = projectsService;
        this.$sce = $sce;
    }
  
    $onChanges(changes) {
        if (changes.rid) {
            this.somedata$ = this.getScanResultDetails(changes.rid.currentValue);
        };
    }
  
    getWrappedString(str){
      try{
        var wrappedText = '';
        var resultArr = str.split(/\r?\n/);
        if (resultArr != null){
          for (var i = 0; i < resultArr.length; ++i){
            if (resultArr[i].length > 70){
              wrappedText += resultArr[i].slice(0, 70) + '..' ;
            }
            else{
              wrappedText += resultArr[i];
            }
            wrappedText += '\n';
            if (i > 20) break;
          }
        }
      }
      catch(err) {
        wrappedText = str;
      } 
      return wrappedText;
    }
  
    getScanResultDetails(rid) {
        this.projectsService.rid = rid;
        return this.projectsService.getScanResultDetails$.subscribe(
            x => {
                this.itemDetails = x.data;
                this.itemDetailsVulnerability = x.data.details.map(x => {
      	            const idxStart = Math.max(x.taintedStartIndex, 0);
      	            const idxEnd = Math.min(x.taintedEndIndex, x.value.length);
                    if (idxEnd == 0)
                      return [{vulnerable: false, text:'N/A'}];
                    else{
						var strLength = 75;
						var otherLengrh = 25;
						var leftSide = x.value.slice(0, idxStart);
						var redSide = x.value.slice(idxStart, idxEnd + 1);
						var rightSide = x.value.slice(idxEnd + 1);
						if (idxEnd - idxStart + 1 > strLength){
							leftSide = '..';
							redSide = redSide.slice(0, strLength);
							rightSide = '..';
						}
						else {
                  if (leftSide.length > otherLengrh*2)
                    leftSide = leftSide.slice(0, otherLengrh) + '..' + leftSide.slice(leftSide.length-otherLengrh, leftSide.length);
                  if (rightSide.length > otherLengrh)
                    rightSide = rightSide.slice(0, otherLengrh) + '..';
                }

                var wrappedText = this.getWrappedString(x.value);
                return [
                  { vulnerable: false, text: leftSide, fullValue: wrappedText},
                  { vulnerable: true, text: redSide, fullValue: wrappedText},
                  { vulnerable: false, text: rightSide, fullValue: wrappedText}
                ];
              }
                });
                this.codeSnippetBreak = x.data.details.map(x => {
                    if (x.codeSnippet) {
                        return x.codeSnippet.replace(/\n/g, '<br />');
                    }
                    return '';
                });
            });
    }
}
