import angular from 'angular';
import uiRouter from 'angular-ui-router';
import scanResultsDetailsComponent from './scanResultsDetails.component';

let scanResultsDetailsModule = angular.module('scanResultsDetails', [
  uiRouter
])

.component('scanResultsDetails', scanResultsDetailsComponent)

.name;

export default scanResultsDetailsModule;
