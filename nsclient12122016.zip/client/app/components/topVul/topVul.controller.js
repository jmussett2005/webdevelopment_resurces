export default class TopVulController {
  constructor($stateParams, projectsService, $q, $timeout, $scope, $rootScope) {
    "ngInject"
    this.$q = $q;
    this.$scope = $scope;
    this.$timeout = $timeout;
    this.projectsService = projectsService;
    this.getTopVulnerabilities$ = this.getTopVulnerabilities($stateParams.sid);
    // console.log('TopVulController $stateParams.sid', $stateParams.sid);

    $scope.$on("scanId:changed", (event, sid, datetime) =>  {
      // console.log('TopVulController sid changed', sid);
      this.getTopVulnerabilities(sid);
    });
    console.log('this vOL', this)

  }
  $onInit() {
    // this.emptyData = false;
  }
  $onChange(change){
    console.log('change in Vultop', change)
  }
  getTopVulnerabilities(sid) {
    // this.projectsService.sid = sid;
    return this.projectsService.getTopVulnerabilities$.subscribe(
      x => {
        this.list = x.data.vulnerabilities;
        this.topVulCount = x.data.length;
      });
  }
}
