import angular from 'angular';
import uiRouter from 'angular-ui-router';
import topVulComponent from './topVul.component';

let topVulModule = angular.module('topVul', [
  uiRouter
])

.component('topVul', topVulComponent)

.name;

export default topVulModule;
