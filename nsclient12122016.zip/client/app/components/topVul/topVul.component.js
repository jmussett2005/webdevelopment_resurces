import template from './topVul.html';
import controller from './topVul.controller';
import './topVul.styl';

let topVulComponent = {
  restrict: 'E',
  bindings: {sid: '<', emptyData:'<'},
  template,
  controller
  // scope: {
  //   topVul: '&'
  // }
};

export default topVulComponent;
