import template from './scanResultsList.html';
import controller from './scanResultsList.controller';
import './scanResultsList.styl';

let scanResultsListComponent = {
    restrict: 'E',
    bindings:{
        onResultSelected: '&', onEmptyData: '&'
    },
    template,
    controller
};

export default scanResultsListComponent;
