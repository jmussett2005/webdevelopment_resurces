export default class ScanResultsListController {
    constructor(projectsService, $scope, $rootScope) {
        "ngInject";
        this.projectsService = projectsService;

        this.accordionState = {oneAtTime: true};
        this.buttonState = {"radio": 0};

        this.buttons = [
            {name: 'All', icon: 'assets/img/warnings/warning-all.svg', value: 0},
            {name: 'High', icon: 'assets/img/warnings/shield-high.svg', value: 3},
            {name: 'Med', icon: 'assets/img/warnings/shield-med.svg', value: 2},
            {name: 'Low', icon: 'assets/img/warnings/shield-low.svg', value: 1}
        ];

        $scope.$on("scanId:changed", (event, sid, datetime) =>  {
            this.sid = sid;
            if (!this.isInitialized) {
                this.pendingUpdate = true;
            } else {
                this.getScanResults();
            }
        });
    }

    $onInit() {
        this.isInitialized = true;
        if (this.pendingUpdate) {
            this.getScanResults();
        }
    }

    filterSeverity(severity) {
        this.selectedSeverity = severity;
        this._initViewData();
    }

    getScanResults() {
        return this.projectsService.getScanResults$.subscribe(x => {
            this._scanData = x.data;
            this._initViewData();
        });
    }

    get accordionData() {
        if (!this._accordionData) {
            this._initViewData();
        }
        return this._accordionData;
    }

    _initViewData() {
        const rawData = (this._scanData || []);
        this.onEmptyData({data: false});
        if (rawData.length <= 0) {
            this.onEmptyData({data: true});
        }

        this.countBySeverity = rawData.reduce((acc, item) => {
            acc[item.severity] = (acc[item.severity] || 0) + 1; return acc;
        }, [rawData.length, 0, 0, 0]);

        const accordionData = rawData
            .filter(item => !this.selectedSeverity || item.severity === this.selectedSeverity)
            .reduce((acc, item) => {
                acc.set(item.name, [...(acc.get(item.name) || []), item]);
                return acc;
            }, new Map());

        this._accordionData = [...accordionData.entries()].map(([key, items], idx) => [{name: key, isOpen: idx === 0}, items]);

        const [resultSet] = [...accordionData.values()];
        this.onResultSelected({rid: resultSet && resultSet.length && resultSet[0].resultId || null});
    }
}
