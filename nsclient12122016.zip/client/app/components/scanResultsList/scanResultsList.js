import angular from 'angular';
import uiRouter from 'angular-ui-router';
import scanResultsListComponent from './scanResultsList.component';

let scanResultsListModule = angular.module('scanResultsList', [
  uiRouter
])

.component('scanResultsList', scanResultsListComponent)

.name;

export default scanResultsListModule;
