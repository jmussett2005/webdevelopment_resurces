import ScanResultsListModule from './scanResultsList'
import ScanResultsListController from './scanResultsList.controller';
import ScanResultsListComponent from './scanResultsList.component';
import ScanResultsListTemplate from './scanResultsList.html';

describe('ScanResultsList', () => {
  let $rootScope, makeController;

  beforeEach(window.module(ScanResultsListModule));
  beforeEach(inject((_$rootScope_) => {
    $rootScope = _$rootScope_;
    makeController = () => {
      return new ScanResultsListController();
    };
  }));

  describe('Module', () => {
    // top-level specs: i.e., routes, injection, naming
  });

  describe('Controller', () => {
    // controller specs
    it('has a name property [REMOVE]', () => { // erase if removing this.name from the controller
      let controller = makeController();
      expect(controller).to.have.property('name');
    });
  });

  describe('Template', () => {
    // template specs
    // tip: use regex to ensure correct bindings are used e.g., {{  }}
    it('has name in template [REMOVE]', () => {
      expect(ScanResultsListTemplate).to.match(/{{\s?\$ctrl\.name\s?}}/g);
    });
  });

  describe('Component', () => {
      // component/directive specs
      let component = ScanResultsListComponent;

      it('includes the intended template',() => {
        expect(component.template).to.equal(ScanResultsListTemplate);
      });

      it('invokes the right controller', () => {
        expect(component.controller).to.equal(ScanResultsListController);
      });
  });
});
