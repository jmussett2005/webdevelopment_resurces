export default class ActivityController {
  constructor(projectsService) {
    "ngInject"
    this.projectsService = projectsService;
    this.messages = this.getActivity();

  }
  getActivity() {
    return this.projectsService.activityData$.subscribe(
      x => this.messages = x.data.activities);
  }
}
