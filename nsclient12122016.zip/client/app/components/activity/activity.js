import angular from 'angular';
import uiRouter from 'angular-ui-router';
import activityComponent from './activity.component';

let activityModule = angular.module('activity', [
  uiRouter
])

.component('activity', activityComponent)
.name;

export default activityModule;
