import ProjectsModule from './projects'
import ProjectsController from './projects.controller';
import ProjectsComponent from './projects.component';
import ProjectsTemplate from './projects.html';

describe('Projects', () => {
  let $rootScope, makeController;

  beforeEach(window.module(ProjectsModule));
  beforeEach(inject((_$rootScope_) => {
    $rootScope = _$rootScope_;
    makeController = () => {
      return new ProjectsController();
    };
  }));

  describe('Module', () => {
    // top-level specs: i.e., routes, injection, naming
  });

  describe('Controller', () => {
    // controller specs
    it('has a name property [REMOVE]', () => { // erase if removing this.name from the controller
      let controller = makeController();
      expect(controller).to.have.property('name');
    });
  });

  describe('Template', () => {
    // template specs
    // tip: use regex to ensure correct bindings are used e.g., {{  }}
    it('has name in template [REMOVE]', () => {
      expect(ProjectsTemplate).to.match(/{{\s?\$ctrl\.name\s?}}/g);
    });
  });

  describe('Component', () => {
      // component/directive specs
      let component = ProjectsComponent;

      it('includes the intended template',() => {
        expect(component.template).to.equal(ProjectsTemplate);
      });

      it('invokes the right controller', () => {
        expect(component.controller).to.equal(ProjectsController);
      });
  });
});
