import {BehaviorSubject, Observable} from 'rxjs/Rx';
import {SERVER_URL}                  from '../../app.constants';
import {PULL_DELAY_PROJECTS}         from '../../app.constants';
import {PULL_DELAY_INF}              from '../../app.constants';
import {VUL_OVR_TIME_PAGE_SIZE}      from '../../app.constants';

export default class ProjectService {
    constructor($http, $q) {
        "ngInject";
        Object.assign(this, {$http});
        let updateRequired$ = Observable.interval(PULL_DELAY_PROJECTS).startWith(0);
        let updateRequiredInf$ = Observable.interval(PULL_DELAY_INF).startWith(0);

        this.lastScans = VUL_OVR_TIME_PAGE_SIZE;

        this.getVolnerabilityBreakdown$ = (type, sev, sid, pid, snew) => this.getVolnerabilityBreakdown(type, sev, sid, pid, snew);

        // ======== /projects ========
        this.activityData$ = updateRequired$
            .switchMap(() => this.getActivityData());

        this.chartSummaryData$ = updateRequiredInf$
            .switchMap(() => this.getChartSummaryData(this.sid, this.pid, this.mode));

        this.getTopVulnerabilities$ = updateRequiredInf$
            .switchMap(() => this.getTopVulnerabilities(this.sid, this.pid, this.mode));

        this.scansItemsData$ = updateRequired$.switchMap(() => {
            return $q.all([
                this.getScansCompletedData(this.mode),
                this.getScansOngoingData(this.mode)
            ]).then(([completed, ongoing]) => {
                const result = {};

                completed.data.forEach((res) => {
                    result[res.applicationId] = {
                        completed: res
                    };
                });
                ongoing.data.forEach((res) => {
                    if (result[res.applicationId]) {
                        result[res.applicationId].ongoing = res;
                    } else {
                        result[res.applicationId] = {
                            ongoing: res
                        };
                    }
                    return Object.keys(result).map(key => res[key]);
                });
                return result;
            });
        });

        this.getUniqueRequestsGraphData$ = updateRequired$
            .take(1).switchMap(() => this.getUniqueRequestsGraphData(this.pid));

        // ======== /projectlobby ========
        this.getScanResults$ = updateRequiredInf$
            .switchMap(() => this.getScanResults(this.sid, this.pid, this.mode));

        this.getScanResultDetails$ = updateRequired$
            .switchMap(() => this.getScanResultDetails((this.rid > 0) ? this.rid : 0));

        this.getVulnerabilityOverTime$ = updateRequiredInf$
            .switchMap(() => this.getVulnerabilityOverTime(this.pid, this.lastScans, this.offset));

        this.getProjectName$ = updateRequiredInf$
            .switchMap(() => this.getProjectName(this.pid));
    }

    // ======== functions ========

    getActivityData() {
        return this.$http.get(`${SERVER_URL}/activities?pageNumber0&pageSize=100`);
    }

    getChartSummaryData(sid, pid, mode) {
      // console.log('ProjectService.getChartSummaryData', sid, pid, mode);
      if (mode =='all') {
        if (pid <=0 || pid == undefined || pid == NaN) {
          return this.$http.get(`${SERVER_URL}/allScans/vulnerabilities`);
        }
        else
        {
          return this.$http.get(`${SERVER_URL}/application/${pid}/vulnerabilitySummary`);
        }
      }
      else
      {
        if (sid > 0) {
            return this.$http.get(`${SERVER_URL}/scan/${sid}/vulnerabilitySummary`);
        } else {
          // console.log('getChartSummaryData sid <= 0');
            return this.$http.get(`${SERVER_URL}/completedScan/vulnerabilities`);
        }
      }
      // if (mode == undefined || mode == '' || mode =='last') {
      //   if (sid > 0) {
      //       return this.$http.get(`${SERVER_URL}/scan/${sid}/vulnerabilitySummary`);
      //   } else {
      //     // console.log('getChartSummaryData sid <= 0');
      //       return this.$http.get(`${SERVER_URL}/completedScan/vulnerabilities`);
      //   }
      // }
      // else
      // {
      //   if (pid <=0 || pid == undefined || pid == NaN) {
      //     return this.$http.get(`${SERVER_URL}/allScans/vulnerabilities`);
      //   }
      //   else
      //   {
      //     return this.$http.get(`${SERVER_URL}/application/${pid}/vulnerabilitySummary`);
      //   }
      //
      // }
    }

    getScansCompletedData(mode) {
      // console.log('ProjectService.getScansCompletedData mode', mode);
      if (mode == undefined || mode == '' || mode =='last') {
        return this.$http.get(`${SERVER_URL}/completedScan`);
      }
      else {
        // console.log('ProjectService.getScansCompletedData allScans', mode);
        return this.$http.get(`${SERVER_URL}/allScans`);
      }
    }

    getScansOngoingData() {
        return this.$http.get(`${SERVER_URL}/runningScan`);
    }

    getVolnerabilityBreakdown(type, sev, sid, pid, snew) {		
        if (this.mode === "all") {			
			if (pid >= 0){
				return this.$http.get(`${SERVER_URL}/application/${pid}/vulnerabilities?severity=${sev}&new=${snew}`);
			}          
        } else {
          if (sid >= 0){
            return this.$http.get(`${SERVER_URL}/scan/${sid}/vulnerabilities?severity=${sev}&new=${snew}`);
          }
        }
    }

     ///This is new but the query in the api do no send results with true or false
     //getVolnerabilityBreakdown(mode, sev, sid, pid, snew) {
    //
      // if (mode == undefined || mode == '' || mode =='last') {
        //  if(snew == undefined ){
            // this part is because the chart info use this function without tre or false
          //  return this.$http.get(`${SERVER_URL}/scan/${sid}/vulnerabilities?severity=${sev}`);

          //}
          //else {
            //return this.$http.get(`${SERVER_URL}/scan/${sid}/vulnerabilities?severity=${sev}&new=${snew}`);
          //}
      //}
       //else {
         //return this.$http.get(`${SERVER_URL}/application/${pid}/runningScans/vulnerabilities?severity=${sev}&new=${snew}`);
       //}
      //}
    ///

    getTopVulnerabilities(sid, pid, mode) {
      // console.log('ProjectService.getTopVulnerabilities', sid, pid, mode);
      if ( sid <=0 || mode == 'all') {
        return this.$http.get(`${SERVER_URL}/application/${pid}/vulnerabilities?top=6`);
      }
      else  if ( sid > 0)
      {
        return this.$http.get(`${SERVER_URL}/scan/${sid}/vulnerabilities?top=6`);
      }
    }

    getScanResults(sid, pid, mode) {
      if (sid <=0  || sid == undefined || sid == NaN) {
        return this.$http.get(`${SERVER_URL}/application/${pid}/results`);
      }
      else
      {
        return this.$http.get(`${SERVER_URL}/scan/${sid}/results`);
      }
    }

    getScanResultDetails(rid) {
        // if (rid >= 0){
          return this.$http.get(`${SERVER_URL}/results/${rid}`);
        // }
    }
    getVulnerabilityOverTime(pid, lastScans, offset) {
        return this.$http.get(`${SERVER_URL}/application/${pid}/vulnerabilityOverTime?lastScans=` + lastScans + `&offset=` + offset);
    }

    getUniqueRequestsGraphData(pid) {
        return this.$http.get(`${SERVER_URL}/application/${pid}/uniqueRequests?limit=6`);
    }

    getProjectName(pid) {
        return this.$http.get(`${SERVER_URL}/application/${pid}`);
    }

}
