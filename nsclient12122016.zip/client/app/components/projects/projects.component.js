import template from './projects.html';
import controller from './projects.controller';
import './projects.styl';

let projectsComponent = {
  restrict: 'E',
  bindings: {},
  template,
  controller
};

export default projectsComponent;
