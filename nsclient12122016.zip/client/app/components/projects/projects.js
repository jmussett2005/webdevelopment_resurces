import angular from 'angular';
import uiRouter from 'angular-ui-router';
import Activity from '../activity/activity';
import Scans from '../scans/scans';
import projectsComponent from './projects.component';
import ProjectsService from './projects.service';

let projectsModule = angular.module('projects', [
    uiRouter,
    Activity,
    Scans
])

.config(($stateProvider) => {
    "ngInject";
    $stateProvider
        .state('projects', {
            url: '/projects',
            component: 'projects'
        });
})
.component('projects', projectsComponent)
.service('projectsService', ProjectsService)

.name;

export default projectsModule;
