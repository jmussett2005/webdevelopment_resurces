export default class ProjectsController {
    constructor(projectsService, $scope, $rootScope) {
        "ngInject"
        this.$rootScope = $rootScope;
        this.$scope = $scope;
        this.name = 'Projects';
        this.projectsService = projectsService;
        this.getScans();
        this.dropdownMode = '';

        this.$rootScope.$broadcast("dropdownMode:changed", '',true, false);
    }

    getScans() {
        return this.projectsService.scansItemsData$.subscribe(x => this.itemsCount = Object.keys(x).length);
    }
}
