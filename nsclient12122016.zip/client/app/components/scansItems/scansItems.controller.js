import { PROJECTS_LINK } from '../../app.constants';

export default class ScansItemsController {
    constructor($stateParams, projectsService, $q, $timeout, $scope, $rootScope) {
    "ngInject"
    this.$rootScope = $rootScope;
    this.PROJECTS_LINK = PROJECTS_LINK;
    this.projectsService = projectsService;
    this.scans$ = this.getScans();
    this.$q = $q;
    this.$timeout = $timeout;
        this.$stateParams = $stateParams;

    if (!this.mode) { this.mode = 'last'; }

    $scope.$on("mode:changed", (event, mode, sid) =>  {
      this.mode = mode;
      this.projectsService.mode = mode;
      this.scans = this.getScans();
    });
  }
    $onInit() {
        this.resultId = this.$stateParams.resultId;
        // console.log('this.state', this.$stateParams)

    }

  getScans() {
    return this.projectsService.scansItemsData$.subscribe(
      x => {
        this.scans = x;
        // console.log('this.scans', this.scans);
        this.itemsCount = Object.keys(x).length;
        this.$rootScope.$broadcast("high:changed", 111);
      });

  }

  getPopupData() {
    return this.projectsService.scansItemsData$.subscribe(x => this.scans = x);
  }

  // $scope.$on("mode:changed" (event, mode, sid) =>  {
  //   console.log('HeaderController: mode:changed', event, mode, sid);
  //   // $rootScope.$broadcast("mode:changed", mode, sid);
  // })
}
