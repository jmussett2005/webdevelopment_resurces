import template from './scansItems.html';
import controller from './scansItems.controller';
import ResultBar from '../../common/resultsBar/resultsBar.controller';
import './scansItems.styl';

let scansItemsComponent = {
  bindings: {
      itemsCount: '=', items: '=', type: '@'
  },
  restrict: 'E',
  template,
  controller,
  ResultBar
};

export default scansItemsComponent;
