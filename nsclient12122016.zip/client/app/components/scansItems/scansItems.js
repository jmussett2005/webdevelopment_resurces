import angular from 'angular';
import uiRouter from 'angular-ui-router';
import scansItemsComponent from './scansItems.component';

let scansItemsModule = angular.module('scansItems', [
    uiRouter
])

.component('scansItems', scansItemsComponent)

.name;

export default scansItemsModule;
