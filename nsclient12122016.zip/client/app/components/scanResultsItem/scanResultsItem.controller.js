export default class ScanResultsItemController {
    constructor(projectsService, $document, $timeout) {
        "ngInject";
        this.projectsService = projectsService;
        this.itemState = {item: true};
        this.$timeout = $timeout;
        this.$document = $document;
    }
    openItem(item, pickedId) {
        item.isOpen = true;
    }
    toTheDetailsTop() {
        let container = angular.element(document.getElementById('container'));
        let position = container[0].getBoundingClientRect();
        if (position.top < 0) {
            this.$document.scrollToElementAnimated(container);
        }
    }
}
