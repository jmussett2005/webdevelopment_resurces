import template from './scanResultsItem.html';
import controller from './scanResultsItem.controller';
import './scanResultsItem.styl';

let scanResultsItemComponent = {
    restrict: 'E',
    bindings: {
        accordionData: '<', severity: '=', type: '@', onSelected: '&'
    },
    template,
    controller
};

export default scanResultsItemComponent;
