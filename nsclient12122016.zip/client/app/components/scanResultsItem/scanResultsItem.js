import angular from 'angular';
import uiRouter from 'angular-ui-router';
import scanResultsItemComponent from './scanResultsItem.component';

let scanResultsItemModule = angular.module('scanResultsItem', [
  uiRouter
])

.component('scanResultsItem', scanResultsItemComponent)

.name;

export default scanResultsItemModule;
