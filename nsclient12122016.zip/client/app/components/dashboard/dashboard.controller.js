export default class DashboardController {
  constructor($stateParams, $scope, $rootScope, projectsService) {
    "ngInject"
    this.name = 'Dashboard';

    this.pid = 1;
    this.sid = 72;

  }
}
