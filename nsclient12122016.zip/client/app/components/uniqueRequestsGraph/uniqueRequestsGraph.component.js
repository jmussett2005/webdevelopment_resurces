import template from './uniqueRequestsGraph.html';
import controller from './uniqueRequestsGraph.controller';
import './uniqueRequestsGraph.styl';

let uniqueRequestsGraphComponent = {
    restrict: 'E',
    bindings: {
        prid: '<', type: '@'
    },
    template,
    controller
};

export default uniqueRequestsGraphComponent;
