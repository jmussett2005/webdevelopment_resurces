import angular from 'angular';
import uiRouter from 'angular-ui-router';
import uniqueRequestsGraphComponent from './uniqueRequestsGraph.component';

let uniqueRequestsGraphModule = angular.module('uniqueRequestsGraph', [
  uiRouter
])

.component('uniqueRequestsGraph', uniqueRequestsGraphComponent)

.name;

export default uniqueRequestsGraphModule;
