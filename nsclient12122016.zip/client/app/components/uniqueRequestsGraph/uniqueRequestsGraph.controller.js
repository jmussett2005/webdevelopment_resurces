export default class UniqueRequestsGraphController {
    constructor($element, $filter, projectsService) {
        'ngInject';
        this.name = 'Unique request History';
        this.projectsService = projectsService;
        this.$filter = $filter('date');
        this.chartData = [];
        this.$element = $element;
    }
    $onInit() {
        this.drawChart(this.prid);
    }
    drawChart(pid) {
        this.projectsService.pid = pid;
        return this.projectsService.getUniqueRequestsGraphData$.subscribe(x => {
            x.data.map(v => {
                this.date = this.$filter(v.lastRequestTime * 1000, "dd-MM-yy");
                this.hr = this.$filter(v.lastRequestTime * 1000, "HH:mm");
                this.chartData.push({
							      "uniqueRequests": v.uniqueRequests,
                    "category": this.date + '\n' + this.hr
                });
            });

            this.chartData.reverse();
            // SERIAL CHART

            let chart = new AmCharts.AmSerialChart();
            chart.dataProvider = this.chartData;
            chart.categoryField = "category";
            chart.startDuration = 1;
            chart.handDrewScatter = 19;
            chart.handDrewThickness = 7;
            chart.processCount = 993;
            chart.responsive = true;
            chart.autoMargins = true;
            chart.fontSize = 13;
            chart.fontFamily = "Roboto";
            chart.color = "#666";
            chart.theme = "light";
            chart.tapToActivate = false;
            chart.startDuration = 0;

            // AXES
            // category
            var categoryAxis = chart.categoryAxis;
            categoryAxis.gridPosition = 'start';
            categoryAxis.gridAlpha = 0;
            categoryAxis.axisAlpha = 1;
            categoryAxis.axisThickness = 2;
            categoryAxis.tickLength = 0;
            categoryAxis.labelOffset = 2;
            // value
            var valueAxis = new AmCharts.ValueAxis();

            valueAxis.axisFrequency = 4;
            valueAxis.axisTitleOffset = 0;
            valueAxis.position = 'right';
            valueAxis.usePrefixes = true;
            valueAxis.zeroGridAlpha = 1;
            valueAxis.axisAlpha = 0;
            valueAxis.centerLabelOnFullPeriod = false;
            valueAxis.gridAlpha = 0.18;
            valueAxis.gridCount = 4;
            valueAxis.markPeriodChange = false;
            valueAxis.minorGridAlpha = 0;
            valueAxis.tickLength = 0;
            valueAxis.axisThickness = 0;
            valueAxis.ignoreAxisWidth = true;
            valueAxis.title = '';
            valueAxis.titleFontSize = 1;
            valueAxis.titleRotation = 0;
            valueAxis.showFirstLabel = false;
            // valueAxis.inside = true;
            valueAxis.offset = -4;

            chart.addValueAxis(valueAxis);

            // GRAPHS
            // first graph
            var graph = new AmCharts.AmGraph();
            graph.balloonText = "[[title]] : [[value]]";
            graph.bullet = "round";
            graph.clustered = false;
            graph.color = '#333';
            graph.lineThickness = 2;
            graph.id = "AmGraph-1";
            graph.bulletSize = 7;
            graph.bulletColor = '#373050';
            graph.bulletBorderColor = '#fff';
            graph.bulletBorderThickness = 2;
            graph.bulletBorderAlpha = 1;
            graph.lineColor = '#373050';
            graph.lineThickness = 2;
            graph.lineAlpha = 1;
            graph.title = "UR";
            graph.type = "smoothedLine";
            graph.valueField = "uniqueRequests";

            chart.addGraph(graph);

            // WRITE
            chart.write(this.$element[0].querySelector('.chartURDiv'));

        });
    }
}
