import template from './projectlobby.html';
import controller from './projectlobby.controller';
import './projectlobby.styl';

let projectlobbyComponent = {
  restrict: 'E',
  bindings: {},
  template,
  controller
};
export default projectlobbyComponent;
