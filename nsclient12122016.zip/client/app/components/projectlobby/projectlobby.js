import angular from 'angular';
import uiRouter from 'angular-ui-router';
import topVul from '../topVul/topVul';
import projectlobbyComponent from './projectlobby.component';

let projectlobbyModule = angular.module('projectlobby', [
    uiRouter,
    topVul
])

    .config(($stateProvider, $urlRouterProvider) => {
        "ngInject";
        $stateProvider
            .state('projectlobby', {
                url: '',
                component: 'projectlobby',
                abstract: true
                // params: {
                //     autoActivateChild: 'projectlobby.details'
                // }
            })
            .state('projectlobby.details', {
                url: '/:sid/projectlobby/:pid/:mode/details',
                component: 'scanResultsDetails'
            });

        // $urlRouterProvider
        //     .when('{sid}/projectlobby/{pid}/{mode}', '{sid}/projectlabby/{pid}/{mode}/details/{resultId}');
    })
    .component('projectlobby', projectlobbyComponent)
    .name;

export default projectlobbyModule;
