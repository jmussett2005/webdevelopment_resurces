export default class projectlobbyController {
    constructor($stateParams, $scope, $rootScope, projectsService, $location) {
        "ngInject";
        this.projectsService = projectsService;
        this.$rootScope = $rootScope;
        this.sid = $stateParams.sid;
        this.sidOld = this.sid;
        this.pid = $stateParams.pid;
        this.mode = $stateParams.mode;
        this.emptyData = 1;
      
        this.getProjectName$ = this.getProjectName(this.pid);

        this.chartVulOverTimeWidth = 50;
        this.chartWidth = 25;
        this.TopVulkWidth = 25;

        this.$rootScope.$broadcast("mode:changed", this.mode);
        if (this.mode == 'all') {
          this.sid = 0;
        }

        $scope.$on("scanId:changed", (event, scanId) =>  {
          if (this.sidOld != scanId) {
            this.sid = scanId;
            $location.path('/' + scanId + '/projectlobby/' + this.pid + '/' + this.mode + '/details');
          }
        });

        $scope.$on("mode:changed", (event, mode, sid) =>  {
          this.mode = mode;
          this.projectsService.mode = mode;
        });

        $rootScope.$on('$stateChangeSuccess', function(event, toState){
            var aac;
            if(aac === toState && toState.params && toState.params.autoActivateChild){
                $state.go(aac);
            }
        });
      console.log('this lobby', this)
    }


    getProjectName(pid) {
        this.projectsService.pid = pid;
        return this.projectsService.getProjectName$.subscribe(x => this.name = x.data.name);
    }

    getScanResults(sid) {
        return this.projectsService.getScanResults$.subscribe(x => {
            this.list = x.data;
            this.TopVulCount = x.data.length;
        });
    }
  
  onEmptyResult(value) {
    this.emptyData = (value) ? true : false;
    console.log('onEmptyResult',value);
  }
}
