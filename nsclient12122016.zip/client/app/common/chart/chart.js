import angular from 'angular';
import uiRouter from 'angular-ui-router';
import chartComponent from './chart.component';

let chartModule = angular.module('chart', [
  uiRouter
])

.component('chart', chartComponent)

.name;

export default chartModule;
