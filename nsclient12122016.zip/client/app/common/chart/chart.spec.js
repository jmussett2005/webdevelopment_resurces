import ChartModule from './chart'
import ChartController from './chart.controller';
import ChartComponent from './chart.component';
import ChartTemplate from './chart.html';

describe('Chart', () => {
  let $rootScope, makeController;

  beforeEach(window.module(ChartModule));
  beforeEach(inject((_$rootScope_) => {
    $rootScope = _$rootScope_;
    makeController = () => {
      return new ChartController();
    };
  }));

  describe('Module', () => {
    // top-level specs: i.e., routes, injection, naming
  });

  describe('Controller', () => {
    // controller specs
    it('has a name property [REMOVE]', () => { // erase if removing this.name from the controller
      let controller = makeController();
      expect(controller).to.have.property('name');
    });
  });

  describe('Template', () => {
    // template specs
    // tip: use regex to ensure correct bindings are used e.g., {{  }}
    it('has name in template [REMOVE]', () => {
      expect(ChartTemplate).to.match(/{{\s?\$ctrl\.name\s?}}/g);
    });
  });

  describe('Component', () => {
      // component/directive specs
      let component = ChartComponent;

      it('includes the intended template',() => {
        expect(component.template).to.equal(ChartTemplate);
      });

      it('invokes the right controller', () => {
        expect(component.controller).to.equal(ChartController);
      });
  });
});
