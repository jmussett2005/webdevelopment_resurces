import template from './chart.html';
import controller from './chart.controller';
import './chart.styl';
// import baloonTemplate from "../vulPopup/vulPopup.html";

let chartComponent = {
  restrict: 'E',
  bindings: {sid: '<', emptyData: '<'},
  template,
  controller,
  link: function(scope, element, attrs) {
      scope.$watch('sid', function() {
        console.log('chartComponent: sid', sid);
      });
    }
};

export default chartComponent;
