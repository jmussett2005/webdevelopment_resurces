import angular from 'angular';
import uiRouter from 'angular-ui-router';
import ngMaterial from 'angular-material';
import resultsBarComponent from './resultsBar.component';

let resultsBarModule = angular.module('resultsBar', [
    uiRouter,
    ngMaterial
])

.component('resultsBar', resultsBarComponent)

.name;

export default resultsBarModule;
