import template from './resultsBar.html';
import controller from './resultsBar.controller';
import './resultsBar.styl';

let resultsBarComponent = {
    restrict: 'E',
    bindings: {api:'&', type: '@', pid: '@', sid: '@', high: '@', newhigh: '@', medium: '@', newmedium: '@', low: '@', newlow: '@', barheight: '@' },
    template,
    controller
};

export default resultsBarComponent;
