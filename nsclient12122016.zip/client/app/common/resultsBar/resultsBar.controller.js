class resultsBarController {
  constructor($stateParams, projectsService, $q, $timeout, $scope, $rootScope) {
    "ngInject"
    this.projectsService = projectsService;
    this.$q = $q;
    this.$timeout = $timeout;
    this.name = 'resultsBar';

    // console.log('resultsBarController $stateParams', $stateParams);

         $scope.$on("high:changed", (event, high) =>  {
          //  console.log('resultsBarController: high:changed', event, high);
           this.calculateBar();
         })
  }

  $onInit() {
    this.calculateBar();
  }
  calculateBar() {
    // console.log('resultsBarController.calculateBar');

    this.barheight = this.barheight + 'px';
    this.sid = parseInt(this.sid);
    this.pid = parseInt(this.pid);
    this.high = parseInt(this.high);
    this.newhigh = parseInt(this.newhigh);
    this.medium = parseInt(this.medium);
    this.newmedium = parseInt(this.newmedium);
    this.low = parseInt(this.low);
    this.newlow = parseInt(this.newlow);

    // console.log('this.barheight', this.barheight, 'this.high', this.high, 'this.sid', this.sid, 'this.pid', this.pid);
    // console.log('resultsBarController', this.high, this.newhigh,this.medium, this.newmedium, this.low, this.newlow);
    this.total = parseInt(this.high) + parseInt(this.medium) + parseInt(this.low);
    // console.log('resultsBarController', this.sid, this.total, this.high, this.newhigh, this.medium, this.newmedium, this.low, this.newlow);
    if (this.total > 0) {
      this.highN = parseInt(((this.high - this.newhigh) / this.total) * 100);
      this.newHighN = parseInt((this.newhigh / this.total) * 100);
      this.mediumN = parseInt(((this.medium - this.newmedium) / this.total) * 100);
      this.newMediumN = parseInt((this.newmedium / this.total) * 100);
      this.lowN = parseInt(((this.low - this.newlow) / this.total) * 100);
      this.newLowN = parseInt((this.newlow / this.total) * 100);

      this.totalN = this.highN + this.newHighN + this.mediumN + this.newMediumN + this.lowN + this.newLowN;
    }
    else{
      this.highN = this.newHighN = this.mediumN = this.newMediumN = this.lowN = this.newLowN = this.totalN = 0;
    }
    // console.log('resultsBarController', this.sid, this.total, this.highN, this.newHighN, this.mediumN, this.newMediumN, this.lowN, this.newLowN);
     this.snew_false="false";
     this.snew_true="true";
  }

  getPopupData(mode, sev, sid, pid, snew) {
// console.log('getPopupData', mode, sev, sid, pid, snew);

  let vulnerabilities = this.projectsService.getVolnerabilityBreakdown$(mode, sev, sid, pid, snew);

  var data =  {
       scanId: sid,
       severity: sev,
       status_new: snew,
       vulnerabilities: vulnerabilities
  };
    return this.$q(resolve => {

      this.$timeout(() => {
        resolve(data);
      });

    });
  }

  }

  export default resultsBarController;
