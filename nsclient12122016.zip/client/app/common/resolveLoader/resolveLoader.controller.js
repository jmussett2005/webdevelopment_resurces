class ResolveLoaderController {
  constructor() {
  }
}

export default ResolveLoaderController;
