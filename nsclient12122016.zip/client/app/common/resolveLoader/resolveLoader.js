import angular from 'angular';
import uiRouter from 'angular-ui-router';
import resolveLoaderComponent from './resolveLoader.component';

let resolveLoaderModule = angular.module('resolveLoader', [
  uiRouter
])

    .directive('resolveLoader', resolveLoaderComponent)

    .service('LoadingService', () => {
        'ngInject';
        var count = 0;
        return {
            transitionStart: () => {
                if (++count > 0) {
                    let el = angular.element(document.getElementById('loader'));
                    el.removeClass('ng-hide');
                }
            },
            transitionEnd: () => {
                if (--count <= 0){
                    let el = angular.element(document.getElementById('loader'));
                    el.addClass('ng-hide');
                }
            }
        };
    })
    .name;

export default resolveLoaderModule;
