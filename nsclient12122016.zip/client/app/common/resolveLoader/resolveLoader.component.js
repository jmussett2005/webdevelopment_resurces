import template from './resolveLoader.html';
import controller from './resolveLoader.controller';
import './resolveLoader.styl';

let resolveLoaderComponent = ($timeout, $transitions) => {
    "ngInject";
    return {
        restrict: 'E',
        template,
        controller,
        link: function(scope, element) {
            "use strict";

            $transitions.onStart({ }, (trans) => {
                let LoadingService = trans.injector().get('LoadingService');
                LoadingService.transitionStart();
                $timeout(() => trans.promise.finally(LoadingService.transitionEnd), 450);
                // trans.promise.finally(LoadingService.transitionEnd);
            });
        }
    };
};

export default resolveLoaderComponent;

