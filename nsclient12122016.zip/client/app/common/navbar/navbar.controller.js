import LINKS_URL from '../../app.constants';

export default class NavbarController {
    constructor() {
        this.navItems =[
            {icon: 'dashboard-icon.svg', iconSel: 'dashboard-icon-sel.svg', link: '#', name: 'dashboard'},
            {icon: 'project-icon.svg', iconSel: 'project-icon-sel.svg', link: 'projects', name: 'projects'},
            {icon: 'scan-icon.svg', iconSel: 'scan-icon-sel.svg', link: '#', name: 'all scans'},
            {icon: 'mgmt-icon.png', iconSel: 'settings-icon-sel.svg', link: '#', name: 'management'},
            {icon: 'user-icon.png', iconSel: 'user-icon-sel.svg', link: '#', name: 'users & teams'},
            {icon: 'analysis.png', iconSel: 'analysis-sel.svg', link: '#', name: 'data analysis'},
        ];
    }
    openLeftMenu() {
        $mdSidenav('left').toggle();
    };
}
