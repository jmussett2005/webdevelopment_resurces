import controller from './questionMarkTooltip.controller';
import './questionMarkTooltip.styl';
import template from './questionMarkTooltip.html';

var prev = null;

let questionMarkTooltipComponent = ($popover) => {
  "ngInject"
  return {
    restrict: 'A',
    bindings: {
      api: '&',
      type: '@',
      sid: '@',
      high: '@',
      newhigh: '@',
      medium: '@',
      newmedium: '@',
      low: '@',
      newlow: '@'
    },
    scope: {
      questionMarkTooltip: '&',
      trigger: '@'
    },
    template,
    controller,
    link: (scope, elem, attr) => {
      "use strict";

      let myPopover = $popover(elem, {
        scope: scope,
        placement: 'top',
        container: 'body',
        trigger: 'click',
        autoClose: false,
        templateUrl: 'app/common/questionMarkTooltip/questionMarkTooltip.html'
      });

	  // let delaiedHide = ()=>{
    //  setTimeout(function() { closePopup() }, 500);
	  // }
    //
	  // function closePopup(){
		//   myPopover.hide();
	  // }
//-----------------------------

// let showPopup = ()=>{
//   scope.vulPopup()
//     .then(d => {
//
//       let promise = d.vulnerabilities;
//       promise.then(
//         function(payload) {
//   if (prev != null)
//     prev.hide();
//
//
//-----------------------------

      let showPopup = ()=>{
        scope.questionMarkTooltip()
          .then(d => {

        console.log(d.desc);
        console.log(d);
        console.log("oooooo");

        var promise = d.desc;
            promise.then(
              function(payload) {

      	// if (prev != null)
				// 	prev.hide();
				// prev=myPopover;

        let desc = payload.data;
        d = { desc: desc };

        myPopover.$promise.then(myPopover.show);
        scope.description = d.desc;

       console.log(scope.description);

      },
      function(errorPayload) {
        $log.error('failure loading data', errorPayload);
      });
          });
      }
      if(scope.trigger === 'click'){
        showPopup;
      }
      else {
        elem.on('mouseenter', showPopup);
      //elem.on('mouseout', () => {
        //myPopover.$promise.then(delaiedHide);
        // });
      }
    }
  };
};
export default questionMarkTooltipComponent;
