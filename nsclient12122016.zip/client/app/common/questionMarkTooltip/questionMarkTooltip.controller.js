class questionMarkTooltipController {
    constructor() {
      "ngInject"
        this.name = 'questionMarkTooltip';
    }
}

export default questionMarkTooltipController;
