import angular          from 'angular';
import AMoment          from 'angular-moment/angular-moment';
import AmCharts         from 'amstock3/amcharts/amcharts';
import Serial           from 'amstock3/amcharts/serial';
import AmStock          from 'amstock3/amcharts/amstock';
import Header           from './header/header';
import Navbar           from './navbar/navbar';
import Chart            from './chart/chart';
import vulPopup         from './vulPopup/vulPopup';
import ResultsBar       from './resultsBar/resultsBar';
import chartVulOverTime from './chartVulOverTime/chartVulOverTime';
import dropdownMode     from './dropdownMode/dropdownMode';
import ResolveLoader    from './resolveLoader/resolveLoader';
import questionMarkTooltip from './questionMarkTooltip/questionMarkTooltip';

let commonModule = angular.module('app.common', [
    Header,
    Navbar,
    Chart,
    vulPopup,
    ResolveLoader,
    AMoment,
    ResultsBar,
    chartVulOverTime,
    dropdownMode,
    questionMarkTooltip
])
.name;

export default commonModule;
