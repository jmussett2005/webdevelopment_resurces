import template from './dropdownMode.html';
import controller from './dropdownMode.controller';
import './dropdownMode.styl';

let dropdownModeComponent = {
  restrict: 'E',
  bindings: {},
  template,
  controller
};

export default dropdownModeComponent;
