export default class DropdownModeController {
  constructor($stateParams, $mdDialog, $scope, $rootScope) {
    "ngInject"
    var originatorEv;
    this.name = 'dropdownMode';
    this.hasCompletdScan = true;
    //  console.log('DropdownModeController $stateParams', $stateParams);

    this.modeOptions = [];

    this.mode = $stateParams.mode;
    switch (this.mode) {
      case 'all':
        this.modeStatus = "All Completed Scans";
        break;
      case 'last':
        this.modeStatus = "Last Completed Scan";
        break;
      case undefined:
        this.modeStatus = "Last Completed Scan";
        this.mode = 'last';
        break;
      default:
        this.modeStatus = "Last Completed Scan";
        break;
    }

    this.openMenu = function($mdOpenMenu, ev) {
      // console.log('DropdownModeController ev', ev);
      originatorEv = ev;
      $mdOpenMenu(ev);
    };

    this.modeStatusText = function() {
      return 'aaa';
    }

    $scope.$on("dropdownMode:changed", (event, dropdownMode, hasCompletdScan, hasOngoingScan) =>  {
      // console.log('DropdownModeController: dropdownMode:changed', event, 'dropdownMode', dropdownMode, 'hasCompletdScan', hasCompletdScan, 'hasOngoingScan', hasOngoingScan);
      this.hasCompletdScan = hasCompletdScan;
      this.hasOngoingScan = hasOngoingScan;
    })

    $scope.$on("scanId:changed", (event, sid, timestamp, mode, scanState) => {
      // console.log('DropdownModeController: scanId:changed', event, sid, 'timestamp', timestamp, 'mode', mode,'this.mode', this.mode, 'scanState', scanState, 'this.scanState', this.scanState);
      if (this.mode != 'all') {
        switch (scanState) {
          case 1:
            this.modeStatus = "Scan in Progress";
            break;
          case undefined:
          case 2:
          this.scanState = 2;
            let time = new Date(timestamp * 1000);
            let theyear = time.getFullYear();
            let themonth = time.getMonth() + 1;
            let thetoday = time.getDate();
            let thehour = time.getHours();
            let theminute = time.getMinutes();
            if (thehour.toString().length < 2) {
              thehour = '0' + thehour.toString();
            }
            if (theminute.toString().length < 2) {
              theminute = '0' + theminute.toString();
            }
            this.modeStatus = thetoday + "/" + themonth + "/" + theyear.toString().substring(2) + "\n" + thehour + ":" + theminute;
            break;
          }
      }
    })
    $scope.$on("mode:changed", (event, mode) => {
      // console.log('DropdownModeController mode:changed', mode);
      this.mode = mode;
    });

    this.openSpecificScan = function(ev) {
      // console.log('openSpecificScan', ev);
      this.modeStatus = "openSpecificScan";
      this.mode = 'sp';
      this.$rootScope.$broadcast("mode:changed", value.mode, "-1");
    };

    this.openAllScans = function(ev) {
      // console.log('openAllScans', ev);
      this.modeStatus = "All Completed Scans";
      this.mode = 'all';
      $rootScope.$broadcast("mode:changed", 'all', "-1");
    };

    this.openLastCompletedScan = function(ev) {
      // console.log('openLastCompletedScan', ev);
      this.modeStatus = "Last Completed Scan";
      this.mode = 'last';
      $rootScope.$broadcast("mode:changed", 'last', "-1");
    };


  }

  $onInit($rootScope) {
    // this.modeStatus = "Last Completed Scan";
    this.$rootScope = $rootScope;
    // console.log('DropdownModeController this.modeStatus', this.modeStatus);

  }
}
