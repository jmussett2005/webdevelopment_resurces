import angular from 'angular';
import uiRouter from 'angular-ui-router';
import ngMaterial    from 'angular-material';
import dropdownModeComponent from './dropdownMode.component';

let dropdownModeModule = angular.module('dropdownMode', [
  uiRouter,
  ngMaterial
])

.component('dropdownMode', dropdownModeComponent)

.name;

export default dropdownModeModule;
