class VulPopupController {
    constructor() {
      "ngInject"
        this.name = 'vulPopup';
    }
}

export default VulPopupController;
