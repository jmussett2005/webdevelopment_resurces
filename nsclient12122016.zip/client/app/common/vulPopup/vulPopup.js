import angular from 'angular';
import uiRouter from 'angular-ui-router';
import vulPopupComponent from './vulPopup.component';

let vulPopupModule = angular.module('vulPopup', [
    uiRouter
])

.directive('vulPopup', vulPopupComponent)
.name;

export default vulPopupModule;
