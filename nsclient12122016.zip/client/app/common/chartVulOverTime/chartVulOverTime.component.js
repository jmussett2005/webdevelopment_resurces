import template from './chartVulOverTime.html';
import controller from './chartVulOverTime.controller';
import './chartVulOverTime.styl';

let chartVulOverTimeComponent = {
  restrict: 'E',
  bindings: {pid: '@', sid: '@', emData: '<'},
  template,
  controller
};

export default chartVulOverTimeComponent;
