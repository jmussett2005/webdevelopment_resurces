import angular from 'angular';
import uiRouter from 'angular-ui-router';
import chartVulOverTimeComponent from './chartVulOverTime.component';

let chartVulOverTimeModule = angular.module('chartVulOverTime', [
  uiRouter
])

.component('chartVulOverTime', chartVulOverTimeComponent)

.name;

export default chartVulOverTimeModule;
