import {VUL_OVR_TIME_PAGE_SIZE}             from '../../app.constants';
import {VUL_OVR_TIME_VERTICAL_OFFSET}             from '../../app.constants';
export default class ChartVulOverTimeController {

  constructor($stateParams, projectsService, $scope, $rootScope) {
    "ngInject"
    this.name = 'Vulnerabilities Over Time';
    this.projectsService = projectsService;
    this.$rootScope = $rootScope;
    this.chartData = [];
    this.cat = '';
    this.vulOverTimeCount = 0;
    this.pageSize = VUL_OVR_TIME_PAGE_SIZE;
    // if (!this.offset) {this.offset = 0;}
    this.offset = 0;
    this.sid = $stateParams.sid;
    this.mode = $stateParams.mode;
    this.maxValue = 0;
    this.minValue = 0;
    this.ongoingScanCategory = 0;
    this.hasCompletdScan = false;
    this.hasOngoingScan = false;
    this.dropdownMode = 'noscans';
    this.$stateParams = $stateParams;
    // console.log('ChartVulOverTimeController this.offset', this.offset);


    $scope.$on("mode:changed", (event, mode, sid) =>  {
      // console.log('ChartVulOverTimeController: mode:changed', event, mode, sid);
      this.mode = mode;
      $stateParams.mode = mode;
      this.sid = 0;
      $stateParams.sid = 0;
      this.projectsService.mode = mode;
      this.getVulOverTime($stateParams.pid, $stateParams.sid, this.cat,0, mode, this.$stateParams);
    })

  }
  $onInit() {
    this.getVulOverTime(this.$stateParams.pid, this.$stateParams.sid, this.cat, 0, this.$stateParams.mode, this.$stateParams);
    console.log(this)
  }

  getVulOverTime(pid, sid, cat, offset, mode, $stateParams) {

    let validScansCounter, firstSelectedCategory, lastSelectedCategory, selectedCategory, ongoingScanCategory, firstYear, firstDate, t, time, theyear, themonth, thetoday, thehour, theminute, CategoryAxisColor, totalRecordCount;
    this.sid = sid;
    this.projectsService.sid = sid;
    this.projectsService.pid = pid;
    this.projectsService.mode = mode;
    this.projectsService.offset = this.offset;


    return this.projectsService.getVulnerabilityOverTime$.subscribe(
      x => {
        cat = new Date(cat.toString().substring(4).trim());
        cat = cat.getDay() + "/"  + cat.getMonth() + 1 + "/" + cat.getFullYear();

        this.vulOverTimeCount = x.data.totalScans;
        this.$rootScope.$broadcast("totalScans:changed", x.data.totalScans);

        let maxVal1 = 0;
        let maxValAxis1 = 0;
        let maxVal2 = 0;
        let maxValAxis2 = 0;
        x.data.vulnerabilities.forEach(function(item) {
          maxVal1 = Math.max(item.high, item.medium, item.low, maxVal1);
          maxValAxis1 = (parseInt(maxVal1/100)+2) * 100;
          maxVal2 = Math.max(item.uniqueRequests, maxVal2);
          maxValAxis2 = (parseInt(maxVal2/100+ 2)) * 100;
        });
        ongoingScanCategory = 0;
        if (x.data.vulnerabilities[0].scanState == 1) {
          ongoingScanCategory = x.data.vulnerabilities[0].time;
        }
        this.ongoingScanCategory = ongoingScanCategory;

        if (sid == 0 && this.mode != 'all') {
          if (x.data.vulnerabilities[0].scanState == 2) {
            sid = x.data.vulnerabilities[0].scanId;
          }
          else if (x.data.vulnerabilities.length > 1) {
            sid = x.data.vulnerabilities[1].scanId;
          }
        }
        this.hasOngoingScan = false;
        this.hasOngoingScan = false;
        this.chartData = x.data.vulnerabilities.reverse().map((value, key) => {
          let i = this.chartData.length;
          time = new Date(value.time);
          value.dateOrg = this.timeFromMilisec(value.time);
          t = new Date(value.date);
          if (value.scanState == 1) {
            this.hasOngoingScan = true;
            CategoryAxisColor = "#88d154";
            value.date = new Date();
            value.bullet = "assets/img/scans/icon-runningScan.svg";
          }
          else
          {
            this.hasCompletdScan = true;
            CategoryAxisColor = "transparent";
            value.bullet = "";
          }
          value.CategoryAxisColor = CategoryAxisColor;
          value.selected1 = 0;
          value.selected2 = 0;
          if (value.scanId == sid || this.mode == 'all')
          {
            value.selected1 = maxValAxis1;
            value.selected2 = maxValAxis2;
            this.$rootScope.$broadcast("scanId:changed", value.scanId, value.time, this.mode, value.scanState);
          }
          this.chartData.push({
            dateOrg: value.dateOrg,
            value1: value.high,
            value2: value.medium,
            value3: value.low,
            value4: value.uniqueRequests,
            ScanId: value.scanId,
            timestamp: value.time,
            selected1: value.selected1,
            selected2: value.selected2,
            CategoryAxisColor: value.CategoryAxisColor
          });
        });
        // console.log('this.hasOngoingScan', this.hasOngoingScan, 'this.hasCompletdScan', this.hasCompletdScan);
        switch ([this.hasCompletdScan, this.hasOngoingScan]) {
          case [false, false]:
            this.dropdownMode = 'noscans';
            break;
          case [true, false]:
            this.dropdownMode = 'completedonly';
            break;
          case [false, true]:
            this.dropdownMode = 'ongoingonly';
            break;
          case [true, true]:
            this.dropdownMode = 'both';
            break;
        }
        // console.log('this.dropdownMode', this.dropdownMode);
        // this.hasCompletdScan = false;
        // this.hasOngoingScan = false;
        this.$rootScope.$broadcast("dropdownMode:changed", this.dropdownMode, this.hasCompletdScan, this.hasOngoingScan);


        let pageSize = VUL_OVR_TIME_PAGE_SIZE;
        let k = this.vulOverTimeCount;
        for (let i = 0; i < pageSize - k; i++) {
         x.data.vulnerabilities.push({
           dateOrg: 0,
           date: 0,
           scanId: 0,
           time: 0,
           CategoryAxisColor: CategoryAxisColor
         });
         let j = x.data.vulnerabilities.length - 1;
         x.data.vulnerabilities[j].scanId = 0;
         x.data.vulnerabilities[j].time = 0;
        }
        firstDate = new Date('2016-01-01');
        for (let i = 0; i < x.data.vulnerabilities.length; i++) {
          let newDate = new Date(firstDate.getTime() + (i * 86400000));
          // x.data.vulnerabilities[i].date = newDate;
          x.data.vulnerabilities[i].labelColor = "#990000";
          if (this.sid == x.data.vulnerabilities[i].scanId) {
            cat = newDate
            this.cat = cat;
          };
          x.data.vulnerabilities[i].dashLenght = 4;
          x.data.vulnerabilities[i].high += VUL_OVR_TIME_VERTICAL_OFFSET;
          x.data.vulnerabilities[i].medium += VUL_OVR_TIME_VERTICAL_OFFSET;
          x.data.vulnerabilities[i].low += VUL_OVR_TIME_VERTICAL_OFFSET;

        }

        firstYear = 2001;
        validScansCounter = 0;
        for (let i = 0; i < x.data.vulnerabilities.length; i++) {
          let newYear = firstYear + i;
          x.data.vulnerabilities[i].date = newYear;
          if (this.sid == x.data.vulnerabilities[i].scanId) {
            cat = newYear
            this.cat = cat;
          };
          if (x.data.vulnerabilities[i].time > 0) {

            validScansCounter +=1 ;
          }
        }
        // console.log('validScansCounter', validScansCounter, 'sid', sid, 'x.data.vulnerabilities', x.data.vulnerabilities, 'length', x.data.vulnerabilities.length, 'mode', mode);
        firstSelectedCategory = 0;
        lastSelectedCategory = 0;
        if (mode == 'all') {
          firstSelectedCategory = x.data.vulnerabilities[0].time;
          if (validScansCounter > 0) {
            if (x.data.vulnerabilities[validScansCounter-1].scanState == 1) {
              lastSelectedCategory = x.data.vulnerabilities[validScansCounter-2].time;
            }
            else {
            lastSelectedCategory = x.data.vulnerabilities[validScansCounter-1].time;
            }

          }
          // console.log('firstSelectedCategory', firstSelectedCategory, 'lastSelectedCategory', lastSelectedCategory);
        }
        else {
          let record = x.data.vulnerabilities.filter(x=>x.scanId == sid);
          if (record.length > 0) {
            selectedCategory = record[0].time;
            firstSelectedCategory = record[0].time;
            lastSelectedCategory = record[0].time;
          }
          else
          {
            firstSelectedCategory = 0;
            lastSelectedCategory = 0;
            selectedCategory = 0;
         }
        }
        this.TopVulCount = x.data.length;


        let chart = AmCharts.makeChart("chartVulOverTimediv", {
          "dataProvider": x.data.vulnerabilities,
          "type": "serial",
          "theme": "light",
          "autoMargins": true,
          "addClassNames": true,
          "legend": {
            "equalWidths": false,
            "periodValueText": "total: [[value.sum]]",
            "position": "top",
            "valueAlign": "left",
            "valueWidth": 100
          },
          "plotAreaBorderAlpha": 0,
          "marginTop": 3,
          "marginLeft": 0,
          "marginBottom": 0,
          "chartScrollbar": {
            "enabled": false
          },
          "legend": {
            "labelWidth": 250,
            "position": "top",
            "enabled": false
          },
          "autoMargins": true,
          "valueAxes": [{
            "inside": false,
            "labelsEnabled": true,
            "integersOnly": true,
            "position": "right",
            "color": "#9b9b9b",
            "fontSize": 13,
            "gridAlpha": 0.3,
            "axisAlpha": 0,
            "autoGridCount": false,
            "gridCount": 4,
            "gridColor": "#999",
            "valueBalloonsEnabled": false,
            "valueLineBalloonEnabled": false,
            // "labelText": "[[value]]",
            "labelFunction": this.valueAxisLabelFunction,
            "showFirstLabel": false,
            "showLastLabel": true
          }],
          "chartScrollbarSettings": {
            "enabled": false
          },
          "showValueAxis": false,
          "graphs": [{
            "id": "g1",
            "columnWidth": 1,
            "showBalloon": true,
            "showHandOnHover": true,
            "useDataSetColors": false,
            "title": "High",
            // "type": "smoothedLine",
            // "type": "serial",
            "lineThickness": 2,
            "valueField": "high",
            "bullet": "round",
            "bulletBorderColor": "#fff",
            "bulletBorderThickness": 12,
            "lineColor": "#da2945",
            "connect": false,
            "balloon": {
              "animationDuration": 0,
              "disableMouseEvents": false,
              "color": "#fff",
              "cornerRadius": 5,
              "fillColor": "#da2945",
              "borderColor": "#da2945",
              "borderThickness": 0,
              "textAlign": "middle"
            },
            "balloonFunction": this.graphBalloonFunction,
            "listeners": [{
              "event": "clickGraphItem",
              "method": (e) => {
                console.log("Clicked on " + e.item.dataContext.scanId, e);
                cat =   e.item.dataContext.date;
                sid = e.item.dataContext.scanId ;
                this.sid = sid;
                this.chartClicked(pid, e.item.dataContext.scanId, e.item.dataContext.time, offset, e.item.dataContext.date, this.mode, e.item.dataContext.scanState);
                this.modifyAxis(e);
              }
            }]
          }, {
            "id": "g2",
            "showHandOnHover": true,
            "useDataSetColors": false,
            "title": "Med",
            "showBalloon": true,
            // "type": "smoothedLine",

            "lineThickness": 2,
            "valueField": "medium",
            "useDataSetColors": false,
            "bullet": "round",
            "lineColor": "#ffb400",
            "connect": false,
            "balloon": {
              "animationDuration": 0,
              "color": "#000",
              "cornerRadius": 5,
              "borderColor": "#ffb400",
              "adjustBorderColor": false,
              "fillColor": "none",
              "borderThickness": 0,
              "textAlign": "middle"
            },
            "balloonFunction": this.graphBalloonFunction,
            "listeners": [{
              "event": "clickGraphItem",
              "method": (e) => {
                cat =   e.item.dataContext.date;
                sid = e.item.dataContext.scanId;
                this.sid = sid;
                this.chartClicked(pid, e.item.dataContext.scanId, e.item.dataContext.time, offset, e.item.dataContext.date, this.mode, e.item.dataContext.scanState);
                this.modifyAxis(e);
              }
            }]
          }, {
            "id": "g3",
            "showHandOnHover": true,
            // "dashLengthField": "dashLenght",
            // "dashLength": 4,
            "showBalloon": true,
            "useDataSetColors": false,
            "title": "Low",
            // "type": "smoothedLine",
            "lineThickness": 2,
            "valueField": "low",
            "useDataSetColors": false,
            "bullet": "round",
            "columnWidth": 1,
            "lineColor": "#ffe10a",
            "connect": false,
            "balloon": {
              "adjustBorderColor": false,
              "animationDuration": 0,
              "color": "#000",
              "cornerRadius": 5,
              "fillColor": "none",
              "borderColor": "#ffe10a",
              "borderThickness": 0
            },
            "balloonFunction": this.graphBalloonFunction,
            "listeners": [{
              "event": "clickGraphItem",
              "method": (e) => {
                // console.log("Clicked on " + e.item.dataContext.scanId, e);
                cat =   e.item.dataContext.date;
                sid = e.item.dataContext.scanId ;
                this.sid = sid;
                this.chartClicked(pid, e.item.dataContext.scanId, e.item.dataContext.time, offset, e.item.dataContext.date, this.mode, e.item.dataContext.scanState);
                this.modifyAxis(e);
              }
            }]
          }],
          "categoryField": "time",
          "chartCursor": {
            "fillColor": "#fff",
            "cursorAlpha": 0.5,
            "fullWidth": true,
            "leaveCursor": false,
            // "categoryBalloonFunction": this.categoryBalloonFunction,
            // "categoryBalloonColor": "#000",
            "categoryBalloonEnabled": false,
            "valueBalloonsEnabled": false,
            "animationDuration": 0,
            "listeners": [{
              "event": "clickItem",
              "method": (e) => {
                // console.log('Clicked on', e, 'e.chart.chartData', e.chart.chartData, 'e.value', e.value, e.serialDataItem, e.axis, e.target, e.chart, e.event );
                let y = e.value.toString().replace('\n', ' ');
                y = y.substring(0, y.indexOf('(')).trim();
                let rec = e.chart.chartData.filter(x=>x.dataContext.dateOrg == y)[0].dataContext;
                sid = rec.scanId;
                cat = rec.date;
                this.chartClicked(pid, rec.scanId, rec.time, offset, rec.date, this.mode, rec.scanState);
                chart.addListener("drawn",this.modifyAxis);
                chart.addListener("zoomed",this.modifyAxis);
              }
            }]
          },
          "categoryAxis": {
            "enabled": true,
            "offset": 2,
            "startOnAxis": false,
            "centerLabels": true,
            "equalSpacing": false,
            "labelFunction": this.formatScanTime,
            "axisColor": "#9b9b9b",
            "color": "#9b9b9b",
            "axisAlpha": 1,
            "gridAlpha": 0,
            "axisThickness": 2,
            "axisColor": "#000",
            // "labelColorField": "labelColor",
            "guides": [{
                category: firstSelectedCategory,
                toCategory: lastSelectedCategory,
                lineColor: "#373050",
                lineAlpha: 1,
                fillAlpha: 1,
                fillColor: "#373050",
                expand: true,
                dashLength: 1,
                inside: false,
                labelRotation: 90,
                label: ""
            },
            {
                category: ongoingScanCategory,
                toCategory: ongoingScanCategory,
                lineColor: "#88d154",
                lineAlpha: 1,
                fillAlpha: 0.2,
                fillColor: "#88d054",
                // fillColor: "#88d154",
                expand: true,
                dashLength: 1,
                inside: false,
                labelRotation: 90,
                label: ""
            }],
            "listeners": [{
              "event": "clickItem",
              "method": (e) => {
                // console.log('Clicked on', e, 'e.chart.chartData', e.chart.chartData, 'e.value', e.value, e.serialDataItem, e.axis, e.target, e.chart, e.event );
                let y = e.value.toString().replace('\n', ' ');
                y = y.substring(0, y.indexOf('(')).trim();
                let rec = e.chart.chartData.filter(x=>x.dataContext.dateOrg == y)[0].dataContext;
                sid = rec.scanId;
                cat = rec.time;
                this.chartClicked(pid, rec.scanId, rec.time, offset, rec.date, this.mode, rec.scanState);
                this.modifyAxis(e);
              }
            },{
              "event": "rollOverItem",
              "method": (e) => {
                chart.chartCursor.showCursorAt(e.serialDataItem.category);
              }
            },{
              "event": "rollOutItem",
              "method": (e) => {
                // console.log('rollOutItem e', e);
                this.modifyAxis(e);
                chart.chartCursor.hideCursor();
              }
            }]
          },
          "listeners": [{
            "event": "changed",
            "method": (event) => {
              // console.log('listeners event changed');
              chart.cursorDataContext = event.chart.dataProvider[event.index];
              this.modifyAxis(event);
            }
          }, {
            "event": "rendered",
            "method": (event) => {
              event.chart.chartDiv.addEventListener('click', () => {
                // console.log('event rendered', event, 'chart.cursorDataContext', 'chart', chart, chart.cursorDataContext);
                if (chart.cursorDataContext != undefined) {
                  sid = chart.cursorDataContext.scanId;
                  cat = chart.cursorDataContext.time;
                  this.chartClicked(pid, sid, cat, offset, chart.cursorDataContext.date, mode, chart.cursorDataContext.scanState);
                  this.modifyAxis(event);
                }
              });
            }
          }]
        });
        // console.log('chartVulOveTimeController: chart.valueAxes', chart.valueAxes[0], ' maxValue', chart.valueAxes[0].max, chart.valueAxes[0].min);
        this.maxValue = chart.valueAxes[0].max;
        this.minValue = chart.valueAxes[0].min;
        chart.addListener("drawn",this.modifyAxis);
        chart.addListener("zoomed",this.modifyAxis);
      });
}


modifyAxis(e) {
  // console.log('modifyAxis e', e);
  let i1, i2;
	var axes = [e.chart.categoryAxis]; //e.chart.valueAxes;

	for ( i1 in axes ) {
		var labels = axes[i1].allLabels;
		var parent = labels[0].node.parentNode;

		for ( i2 in labels ) {
      // console.log('labels[i2].node.textContent', labels[i2].node.textContent);
      if (labels[i2].node.textContent.toLowerCase() == '.') {
        // console.log('modifyAxis labels[i2].node', i2, labels[i2].node.textContent);
  			var label = labels[i2].node;
  			var group = document.createElementNS('http://www.w3.org/2000/svg', "g");
  			var img   = document.createElementNS('http://www.w3.org/2000/svg', "image");

  			// Setup image
  			img.setAttributeNS('http://www.w3.org/1999/xlink', 'href', 'assets/img/scans/scan_light_bg.gif');
        // img.setAttributeNS('http://www.w3.org/1999/xlink', 'href', 'assets/img/chart/high-new.png');
        group.addEventListener("click", () => {
              console.log("Clicked", this);
              let record = e.chart.chartData.filter(x=>x.category == this.ongoingScanCategory);
               console.log('pid', this.pid, 'sid', record[0].dataContext.scanId, 'time', this.ongoingScanCategory, 'offset', this.offset, 'cat', this.ongoingScanCategory, 'mode', this.mode, 'scanState', record[0].dataContext.scanState);
                console.log('record', record);
              this.chartClicked(this.pid, record[0].dataContext.scanId,  this.ongoingScanCategory, this.offset, this.ongoingScanCategory, this.mode, record[0].dataContext.scanState);
              // chartClicked(pid, sid, time, offset, cat, mode, scanState)
            });
  			img.setAttribute('x','-12');
  			img.setAttribute('y','-3'); // half the height
  			img.setAttribute('width','24');
  			img.setAttribute('height','24');
        label.setAttribute('background-color','#000');
        label.setAttribute('style','background-color: red');
        label.setAttribute('cursor','pointer');
        group.setAttribute('cursor','pointer');
  			// Swap position to group; remove from label
  			group.setAttribute('transform',label.getAttribute('transform'));
        group.setAttribute('style',label.getAttribute('style'));
  			// label.setAttribute('transform','');

  			// Group axis labels
  			group.appendChild(label);
  			group.appendChild(img);
  			parent.appendChild(group);
      }
		}
	}
}


timeFromMilisec(val) {
  let time = new Date(val * 1000);
  let theyear = time.getFullYear();
  let themonth = time.getMonth() + 1;
  let thetoday = time.getDate();
  let thehour = time.getHours();
  let theminute = time.getMinutes();
  if (thehour.toString().length < 2) {
    thehour = '0' + thehour.toString();
  }
  if (theminute.toString().length < 2) {
    theminute = '0' + theminute.toString();
  }
  return thetoday + "/" + themonth + "/" + theyear.toString().substring(2) + " " + thehour + ":" + theminute;

}

formatScanTime(value, valueString, axis) {
  let newValue = 0;
  let thisTime = -1;
  let gotValue = false;
  let thisScanState = valueString.dataContext.scanState;
  let thisUniqRequests = valueString.dataContext.uniqueRequests;

 if (value == 0) {
   return ""; }

  let time = new Date(value * 1000);
  let theyear = time.getFullYear();
  let themonth = time.getMonth() + 1;
  let thetoday = time.getDate();
  let thehour = time.getHours();
  let theminute = time.getMinutes();
  if (thehour.toString().length < 2) {
    thehour = '0' + thehour.toString();
  }
  if (theminute.toString().length < 2) {
    theminute = '0' + theminute.toString();
  }
  if (thisTime == 0)
  {
    newValue = "";
  }
  else{
    newValue = thetoday + "/" + themonth + "/" + theyear.toString().substring(2) + "\n" + thehour + ":" + theminute + "\n(URs " + thisUniqRequests + ")";
  }
  if (thisScanState == 1) {
    // newValue = "ongoing";
    newValue = ".";
  }
  return newValue;
}
graphBalloonFunction(value, a, b, c) {
  // console.log('graphBalloonFunction', value, a, b, c);
  // console.log('value.values.value', value.values.value);
  let x = value.values.value - VUL_OVR_TIME_VERTICAL_OFFSET;
  // return value.values.value;
  return x.toString();
  // return "22";

}
valueAxisLabelFunction(value) {
  // console.log('valueAxisLabelFunction: value', value);
  return value - VUL_OVR_TIME_VERTICAL_OFFSET;
}

  categoryBalloonFunction(value) {
  // console.log('categoryBalloonFunction: value', value);
  let newValue = 0;
  let thisTime = -1;
  let time = new Date(value * 1000);
  let theyear = time.getFullYear();
  let themonth = time.getMonth() + 1;
  let thetoday = time.getDate();
  let thehour = time.getHours();
  let theminute = time.getMinutes();
  if (thehour.toString().length < 2) {
    thehour = '0' + thehour.toString();
  }
  if (theminute.toString().length < 2) {
    theminute = '0' + theminute.toString();
  }
  if (thisTime == 0)
  {
    newValue = "";
  }
  else{
    newValue = thetoday + "/" + themonth + "/" + theyear.toString().substring(2) + "\n" + thehour + ":" + theminute;
  }
  return newValue;
}
    volOverTime_Prev() {
      // console.log('volOverTime_Prev', this.pid, this.sid, this.offset);
       this.offset = this.offset + 1;
       this.getVulOverTime(this.pid, this.sid, this.cat, this.offset);

    }
    volOverTime_Next() {
      // console.log('volOverTime_Next', this.pid, this.sid, this.offset);
      if (this.offset > 0) {
        this.offset = this.offset - 1;
        this.getVulOverTime(this.pid, this.sid, this.cat, this.offset);
      }
    }

    chartClicked(pid, sid, time, offset, cat, mode, scanState) {
        // console.log('ChartVulOverTime1Controller: chartClicked', pid, sid, time, offset, cat, mode, 'scanState', scanState);
        if (sid == 0) {
          return;
        }
      if (this.mode != 'last') {
        this.mode = 'last';
        this.$rootScope.$broadcast("mode:changed", this.mode);
      }

      this.sid = sid;
      this.$rootScope.$broadcast("scanId:changed", sid, time, this.mode, scanState);
      // console.log('ChartVulOverTime1Controller: broadcast scanId:changed',sid);
      this.getVulOverTime(pid, sid, cat, offset);
    }
}
