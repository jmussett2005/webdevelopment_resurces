class HeaderController {
  constructor($stateParams, $scope, $rootScope) {
    "ngInject"
    this.$scope = $scope;
    this.name = 'header';
    this.statusLabel = "LAST COMPLETED SCAN";

    // console.log('HeaderController $stateParams', $stateParams);
    this.mode = $stateParams.mode;

    $scope.$on("scanId:changed", (event, sid, datetime, mode, scanState) =>  {
        // console.log('HeaderController sid changed', sid, 'datetime', datetime, 'this.mode', this.mode, 'scanState', scanState);
      switch (scanState) {
        case undefined:
          break;
        case 1:
          this.statusLabel = "Scan in Progress";
          this.scanState = scanState;
          break;
        case 2:
          let time = new Date(datetime * 1000);
          let theyear = time.getFullYear();
          let themonth = time.getMonth() + 1;
          let thetoday = time.getDate();
          let thehour = time.getHours();
          let theminute = time.getMinutes();
          if (thehour.toString().length < 2) {
            thehour = '0' + thehour.toString();
          }
          if (theminute.toString().length < 2) {
            theminute = '0' + theminute.toString();
          }
          this.scanState = scanState;
          this.statusLabel = thetoday + "/" + themonth + "/" + theyear.toString().substring(2) + " " + thehour + ":" + theminute;
          break;
    }
    })
    if (!this.mode) {
      this.mode = 'last';
    }

    $scope.$on("mode:changed", (event, mode, sid) =>  {
      // console.log('HeaderController: mode:changed', event, mode, sid);
      // $rootScope.$broadcast("mode:changed", mode, sid);
    })
  }
}

export default HeaderController;
