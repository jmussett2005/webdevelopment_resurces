import template from './header.html';
import controller from './header.controller';
import './header.styl';

let headerComponent = {
  restrict: 'E',
  bindings: {mode: '@'},
  template,
  controller
};

export default headerComponent;
