import angular       from 'angular';
import uiRouter      from 'angular-ui-router';
import ngMaterial    from 'angular-material';
import ngSanitize    from 'angular-sanitize';
import ngAnimate     from 'angular-animate';
import ngFilter      from 'angular-filter';
import ngMoment      from 'angular-moment/angular-moment';
import duScroll      from 'angular-scroll';
import 'angular-strap/dist/angular-strap';
import 'angular-strap/dist/angular-strap.tpl';
import 'angular-sticky-plugin/dist/angular-sticky.min';
import 'ns-popover/src/nsPopover';
import Common        from './common/common';
import Components    from './components/components';
import AppComponent  from './app.component';
import AppConst      from './app.constants';
import tooltip       from 'angular-ui-bootstrap/src/tooltip';
import accordion     from 'angular-ui-bootstrap/src/accordion';
import pagination    from 'angular-ui-bootstrap/src/pagination';
import 'normalize.css';

angular.module('app', [
    'mgcrea.ngStrap',
    'nsPopover',
    'hl.sticky',
    duScroll,
    uiRouter,
    ngMaterial,
    ngAnimate,
    ngFilter,
    ngSanitize,
    ngMoment,
    tooltip,
    accordion,
    pagination,
    Common,
    Components
])

    .constant('AppConst', AppConst)
    .config(($urlRouterProvider, $locationProvider) => {
        "ngInject";
        // @see: https://github.com/angular-ui/ui-router/wiki/Frequently-Asked-Questions
        // #how-to-configure-your-server-to-work-with-html5mode
        $locationProvider.html5Mode(true).hashPrefix('!');
        $urlRouterProvider.when('/','/projects');
    })
    .component('app', AppComponent);
